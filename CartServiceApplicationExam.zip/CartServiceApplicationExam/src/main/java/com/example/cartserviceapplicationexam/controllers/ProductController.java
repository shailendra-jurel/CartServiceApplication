package com.example.cartserviceapplicationexam.controllers;

import com.example.cartserviceapplicationexam.models.Product;
import com.example.cartserviceapplicationexam.Service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
public class ProductController {

    private ProductService productService;

    @Autowired
    public ProductController(ProductService productService) {
        this.productService = productService;
    }

    @GetMapping("/products")
    public List<Product> getAllProducts() {
        return productService.getAllProducts();
    }

    @GetMapping("/products/{id}")
    public Product getSingleProduct(@PathVariable Long id) {
        return productService.getSingleProduct(id);
    }

    @PostMapping("/products")
    public Product createProduct(@RequestBody Product product) {
        return productService.createProduct(product);
    }

    @GetMapping("/cart")
    public List<Product> buyLater() {
        return new ArrayList<>();
    }

    @PutMapping("/products/{id}")
    public Product addSingleProduct(@PathVariable Long id) {
        return productService.addSingleProduct(id);
    }

    @DeleteMapping("/products/{id}")
    public Product deleteSingleProduct(@PathVariable Long id) {
        return productService.deleteSingleProduct(id);
    }
}
