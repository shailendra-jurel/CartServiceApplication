package com.example.cartserviceapplicationexam.models;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class Category {
    public Long id;
    public String name;
}