package com.example.cartserviceapplicationexam.Service;

import com.example.cartserviceapplicationexam.models.Product;

import java.util.List;

public interface ProductService {
    List<Product> getAllProducts();

    Product getSingleProduct(Long id);

    Product createProduct(Product product);
}