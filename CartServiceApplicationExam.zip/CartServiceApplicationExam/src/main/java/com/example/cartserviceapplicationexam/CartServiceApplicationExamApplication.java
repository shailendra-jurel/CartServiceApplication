package com.example.cartserviceapplicationexam;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CartServiceApplicationExamApplication {

    public static void main(String[] args) {
        SpringApplication.run(CartServiceApplicationExamApplication.class, args);
    }
}
