package com.example.cartserviceapplicationexam;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CartServiceApplicationExamApplicationTests {

    @Test
    void contextLoads() {
    }

}
